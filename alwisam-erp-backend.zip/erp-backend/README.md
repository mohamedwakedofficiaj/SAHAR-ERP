# Al-Wisam ERP — Backend

Real multi-company ERP backend: PostgreSQL database, Express API, JWT auth,
double-entry accounting engine (Universal Journal), and the existing frontend
bundled as static files so ONE deployment serves both the API and the UI.

## What's actually real here

- Every business action that should move money (PO receipt, subcontractor
  certificate approval, installment collection, expense recording, custody
  issuance, supplier payment) posts a **real balanced double-entry journal**
  via `src/services/postingEngine.js` — not just a UI update.
- Multi-company isolation is enforced **at the API layer**
  (`src/middleware/companyScope.js`), not just hidden in the frontend menu.
- Each company has its own chart of accounts; the consolidated view merges
  them and nets out intercompany balances (see `/api/reports/consolidated-trial-balance`).

## Project structure

```
src/
  server.js              — app entry point, wires everything together
  db/
    schema.sql            — full PostgreSQL schema
    seedLogic.js           — seed data logic (companies, accounts, sample records)
    seed.js                 — CLI: `node src/db/seed.js`
    seed-inline.js           — used by server.js's auto-setup (RUN_SETUP=true)
    migrate.js               — CLI: `node src/db/migrate.js` (applies schema.sql)
    pool.js                    — PostgreSQL connection pool
  middleware/
    auth.js                — verifies JWT
    companyScope.js         — enforces "can this user touch this company's data?"
  services/
    postingEngine.js         — the only code allowed to write to the ledger
  routes/                     — one file per resource (customers, suppliers, banks...)
public/
  index.html                — the existing frontend (still using its own local demo
                               data for now — wiring it to call this API is the next
                               phase, not yet done in this package)
```

## Running it locally (optional — only if you want to test before deploying)

```bash
npm install
cp .env.example .env      # then edit .env with your own values
node src/db/migrate.js    # creates all tables
node src/db/seed.js       # loads sample data + the admin user
npm run dev                # starts the server on http://localhost:4000
```

## Running it with zero command line (recommended for non-technical deployment)

Set the environment variable `RUN_SETUP=true` in your hosting provider's
dashboard. On boot, the server checks if the schema exists; if not, it applies
`schema.sql` and the seed data automatically, then starts normally. See the
separate step-by-step deployment guide for the full walkthrough.

**Default login after seeding:** `mohamedwakedofficial@gmail.com` / `ChangeMe123!`
— change this password immediately after your first login.

## Environment variables (see `.env.example`)

| Variable | Purpose |
|---|---|
| `DATABASE_URL` | PostgreSQL connection string |
| `JWT_SECRET` | Long random string — used to sign login tokens |
| `RUN_SETUP` | Set to `true` once to auto-create the database structure and seed data |
| `PORT` | Usually set automatically by the hosting provider |
| `CORS_ORIGINS` | Comma-separated list of allowed frontend origins |

## What is NOT done yet (be clear-eyed about this)

The frontend in `public/index.html` is the same prototype built earlier in
this project — it still stores its data in the browser's local storage, not
by calling this API. Making the two talk to each other (so multiple people
actually share the same live data) is the next phase of work, not included
in this package.
