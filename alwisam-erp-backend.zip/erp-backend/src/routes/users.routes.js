const express = require('express');
const bcrypt = require('bcrypt');
const pool = require('../db/pool');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();
router.use(requireAuth);

function requireAdmin(req, res, next) {
  if (req.user.permissions?.all !== true) {
    return res.status(403).json({ error: 'هذه الشاشة متاحة فقط لحسابات مدير عام.' });
  }
  next();
}

// GET /api/users — list every user in this tenant, with which companies they can access
router.get('/', requireAdmin, async (req, res) => {
  const { rows } = await pool.query(
    `SELECT u.id, u.name, u.email, u.is_active, r.name AS role_name,
            COALESCE(json_agg(c.name) FILTER (WHERE c.id IS NOT NULL), '[]') AS companies
     FROM users u
     LEFT JOIN roles r ON r.id = u.role_id
     LEFT JOIN user_company_access uca ON uca.user_id = u.id
     LEFT JOIN companies c ON c.id = uca.company_id
     WHERE u.tenant_id = $1
     GROUP BY u.id, r.name
     ORDER BY u.name`,
    [req.user.tenantId]
  );
  res.json(rows);
});

// POST /api/users  { name, email, password, role_name, company_ids: [...] }
router.post('/', requireAdmin, async (req, res) => {
  const { name, email, password, role_name, company_ids } = req.body;
  if (!name || !email || !password) {
    return res.status(400).json({ error: 'الاسم، البريد الإلكتروني، وكلمة المرور مطلوبون.' });
  }
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    let { rows: [role] } = await client.query(
      `SELECT id FROM roles WHERE tenant_id = $1 AND name = $2`, [req.user.tenantId, role_name || 'viewer']
    );
    if (!role) {
      ({ rows: [role] } = await client.query(
        `INSERT INTO roles (tenant_id, name, permissions) VALUES ($1,$2,'{}') RETURNING id`,
        [req.user.tenantId, role_name || 'viewer']
      ));
    }
    const passwordHash = await bcrypt.hash(password, 10);
    const { rows: [user] } = await client.query(
      `INSERT INTO users (tenant_id, name, email, password_hash, role_id) VALUES ($1,$2,$3,$4,$5) RETURNING id, name, email`,
      [req.user.tenantId, name, email, passwordHash, role.id]
    );
    for (const companyId of (company_ids || [])) {
      await client.query(`INSERT INTO user_company_access (user_id, company_id) VALUES ($1,$2)`, [user.id, companyId]);
    }
    await client.query('COMMIT');
    res.status(201).json(user);
  } catch (err) {
    await client.query('ROLLBACK');
    res.status(400).json({ error: err.message.includes('duplicate') ? 'البريد الإلكتروني مستخدم بالفعل.' : err.message });
  } finally {
    client.release();
  }
});

// PUT /api/users/:id  { name, is_active, company_ids }
router.put('/:id', requireAdmin, async (req, res) => {
  const { name, is_active, company_ids } = req.body;
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    await client.query(
      `UPDATE users SET name = COALESCE($1,name), is_active = COALESCE($2,is_active) WHERE id = $3`,
      [name, is_active, req.params.id]
    );
    if (Array.isArray(company_ids)) {
      await client.query(`DELETE FROM user_company_access WHERE user_id = $1`, [req.params.id]);
      for (const companyId of company_ids) {
        await client.query(`INSERT INTO user_company_access (user_id, company_id) VALUES ($1,$2)`, [req.params.id, companyId]);
      }
    }
    await client.query('COMMIT');
    res.json({ message: 'تم تحديث المستخدم.' });
  } catch (err) {
    await client.query('ROLLBACK');
    res.status(400).json({ error: err.message });
  } finally {
    client.release();
  }
});

module.exports = router;
