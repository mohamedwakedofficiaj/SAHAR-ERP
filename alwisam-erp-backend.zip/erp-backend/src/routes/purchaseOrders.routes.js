const express = require('express');
const pool = require('../db/pool');
const { requireAuth } = require('../middleware/auth');
const { requireCompanyAccess } = require('../middleware/companyScope');
const { receivePurchaseOrder } = require('../services/postingEngine');

const router = express.Router();
router.use(requireAuth);

// GET /api/purchase-orders?company_id=...
router.get('/', requireCompanyAccess, async (req, res) => {
  const { rows } = await pool.query(
    `SELECT po.*, s.name AS supplier_name
     FROM purchase_orders po
     JOIN suppliers s ON s.id = po.supplier_id
     WHERE po.company_id = $1
     ORDER BY po.order_date DESC`,
    [req.companyId]
  );
  res.json(rows);
});

// POST /api/purchase-orders  { company_id, code, supplier_id, item_description, qty, unit_price, expected_date, inventory_item_id }
router.post('/', requireCompanyAccess, async (req, res) => {
  const { code, supplier_id, item_description, qty, unit_price, expected_date, inventory_item_id } = req.body;
  if (!code || !supplier_id || !item_description || !qty || !unit_price) {
    return res.status(400).json({ error: 'بيانات أمر الشراء غير مكتملة.' });
  }
  try {
    const { rows: [po] } = await pool.query(
      `INSERT INTO purchase_orders (company_id, code, supplier_id, item_description, qty, unit_price, expected_date, inventory_item_id)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,
      [req.companyId, code, supplier_id, item_description, qty, unit_price, expected_date || null, inventory_item_id || null]
    );
    res.status(201).json(po);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'تعذر إنشاء أمر الشراء (تأكد من عدم تكرار الكود).' });
  }
});

// POST /api/purchase-orders/:id/receive — the real cross-module action:
// updates inventory qty AND posts the Dr Inventory / Cr Suppliers journal entry.
router.post('/:id/receive', async (req, res) => {
  try {
    const result = await receivePurchaseOrder(req.user.tenantId, req.params.id, req.user.userId);
    res.json({ message: 'تم استلام أمر الشراء وترحيله محاسبيًا.', ...result });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

module.exports = router;
