const express = require('express');
const pool = require('../db/pool');
const { requireAuth } = require('../middleware/auth');
const { requireCompanyAccess } = require('../middleware/companyScope');

const router = express.Router();
router.use(requireAuth);

router.get('/', requireCompanyAccess, async (req, res) => {
  const { rows } = await pool.query(
    `SELECT * FROM banks WHERE company_id = $1 ORDER BY name`,
    [req.companyId]
  );
  res.json(rows);
});

router.post('/', requireCompanyAccess, async (req, res) => {
  const { name, account_number, currency, balance } = req.body;
  if (!name || !account_number) {
    return res.status(400).json({ error: 'اسم البنك ورقم الحساب مطلوبان.' });
  }
  const { rows: [bank] } = await pool.query(
    `INSERT INTO banks (company_id, name, account_number, currency, balance, statement_balance)
     VALUES ($1,$2,$3,$4,$5,$5) RETURNING *`,
    [req.companyId, name, account_number, currency || 'EGP', balance || 0]
  );
  res.status(201).json(bank);
});

router.put('/:id', async (req, res) => {
  const { name, account_number, reconciliation_status } = req.body;
  const { rows: [bank] } = await pool.query(
    `UPDATE banks SET name = COALESCE($1,name), account_number = COALESCE($2,account_number),
     reconciliation_status = COALESCE($3, reconciliation_status) WHERE id = $4 RETURNING *`,
    [name, account_number, reconciliation_status, req.params.id]
  );
  res.json(bank);
});

// POST /api/banks/:id/deposit  { amount, description }
// NOTE: a generic "deposit with no specified source" only updates the bank
// balance and is logged in bank_transactions for audit. A deposit that has
// a known source (customer collection, capital injection, loan drawdown...)
// should go through the specific posting function for that source instead
// (see collectInstallment in postingEngine.js for the AR example) so it
// hits the correct contra-account rather than an unspecified one.
router.post('/:id/deposit', async (req, res) => {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const { amount, description } = req.body;
    if (!amount || amount <= 0) throw new Error('المبلغ غير صالح.');

    const { rows: [bank] } = await client.query(`SELECT * FROM banks WHERE id = $1 FOR UPDATE`, [req.params.id]);
    if (!bank) throw new Error('البنك غير موجود.');

    await client.query(
      `UPDATE banks SET balance = balance + $1, statement_balance = statement_balance + $1 WHERE id = $2`,
      [amount, req.params.id]
    );
    await client.query(
      `INSERT INTO bank_transactions (bank_id, txn_type, amount, description) VALUES ($1,'deposit',$2,$3)`,
      [req.params.id, amount, description || null]
    );

    await client.query('COMMIT');
    res.json({ message: 'تم تسجيل الإيداع وتحديث رصيد البنك. لترحيله محاسبيًا بحساب مقابل محدد، استخدم نقطة النهاية الخاصة بمصدر الإيداع (تحصيل عميل، إلخ).' });
  } catch (err) {
    await client.query('ROLLBACK');
    res.status(400).json({ error: err.message });
  } finally {
    client.release();
  }
});

module.exports = router;
